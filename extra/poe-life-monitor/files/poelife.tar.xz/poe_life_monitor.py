#!/usr/bin/env python3
"""X11 Path of Exile life monitor using screen OCR.

This reads only the small "Life current/max" area of the screen.  It does not
read game memory, inject input, or interact with the game process.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import threading
import time
import wave

from PIL import Image, ImageGrab


APP_DIR = Path(__file__).resolve().parent
LEGACY_CONFIG_PATH = APP_DIR / "config.json"
CONFIG_HOME = Path(
    os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))
)
CONFIG_PATH = CONFIG_HOME / "poe-life-monitor" / "config.json"
TESSDATA_DIR = APP_DIR / "tessdata"
DEFAULT_CONFIG = {
    "max_life": 3144,
    "threshold": 1572,
    "interval_seconds": 0.10,
    "confirm_readings": 1,
    "rearm_percent": 5,
    "detection": "orb",
    "orb_empty_ratio": 0.55,
    "capture_fps": 20,
    "hud_presence_ratio": 0.55,
    "hud_return_frames": 10,
    "screen": "auto",
    "sound": "builtin",
    "shift_wheel_stash": False,
}

LIFE_RE = re.compile(
    r"Life\D{0,8}([0-9][0-9, ]*)\s*/\s*([0-9][0-9, ]*)",
    re.IGNORECASE,
)
GEOMETRY_RE = re.compile(r"^(\d+)x(\d+)\+(-?\d+)\+(-?\d+)$")


def load_config() -> dict:
    config = dict(DEFAULT_CONFIG)
    config_path = CONFIG_PATH if CONFIG_PATH.exists() else LEGACY_CONFIG_PATH
    if config_path.exists():
        try:
            loaded = json.loads(config_path.read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                raise ValueError("top level must be an object")
            config.update(loaded)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise SystemExit(f"Cannot read {config_path}: {exc}")
    return config


def save_config(config: dict) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")


def parse_threshold(value: str, max_life: int) -> int:
    value = value.strip()
    try:
        if value.endswith("%"):
            percent = float(value[:-1])
            if not 0 < percent < 100:
                raise ValueError
            return round(max_life * percent / 100)
        threshold = int(value.replace(",", ""))
        if not 0 < threshold < max_life:
            raise ValueError
        return threshold
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"threshold must be 1..{max_life - 1}, or a percentage such as 40%"
        ) from None


def parse_geometry(value: str) -> tuple[int, int, int, int]:
    match = GEOMETRY_RE.fullmatch(value)
    if not match:
        raise ValueError("expected WIDTHxHEIGHT+X+Y, for example 2560x1440+0+0")
    width, height, x, y = map(int, match.groups())
    return x, y, width, height


def primary_screen() -> tuple[int, int, int, int]:
    """Return (x, y, width, height), preferring xrandr's primary output."""
    try:
        output = subprocess.run(
            ["xrandr", "--current"], capture_output=True, text=True, check=True
        ).stdout
        lines = [line for line in output.splitlines() if " connected" in line]
        lines.sort(key=lambda line: " connected primary " not in line)
        for line in lines:
            match = re.search(r"(\d+x\d+\+-?\d+\+-?\d+)", line)
            if match:
                return parse_geometry(match.group(1))
    except (OSError, subprocess.SubprocessError, ValueError):
        pass

    # Fall back to the left/top monitor-sized portion of the X11 root window.
    image = ImageGrab.grab(xdisplay=os.environ.get("DISPLAY", ":0"))
    return 0, 0, image.width, image.height


def life_crop(screen: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    """Crop the bottom-left HUD, scaled from the calibrated 2560x1440 layout."""
    x, y, width, height = screen
    scale = height / 1440
    left = x + round(35 * scale)
    top = y + height - round(400 * scale)
    right = x + round(340 * scale)
    bottom = y + height - round(300 * scale)
    return left, top, right, bottom


def orb_threshold_crop(
    screen: tuple[int, int, int, int], threshold_fraction: float
) -> tuple[int, int, int, int]:
    """Return the combined rim-anchor and threshold capture rectangle."""
    return orb_capture_geometry(screen, threshold_fraction)[0]


def orb_capture_geometry(
    screen: tuple[int, int, int, int], threshold_fraction: float
) -> tuple[
    tuple[int, int, int, int],
    tuple[int, int, int, int],
    tuple[int, int, int, int],
]:
    """Return the capture, liquid sub-rectangle, and permanent-rim anchor."""
    x, y, width, height = screen
    scale = height / 1440
    # Calibrated from the current 2560x1440 HUD. The globe is anchored left/bottom.
    orb_top = y + height - round(275 * scale)
    orb_bottom = y + height + round(10 * scale)
    target_y = round(orb_bottom - threshold_fraction * (orb_bottom - orb_top))
    half_band = max(3, round(5 * scale))
    left = x + round(75 * scale)
    top = y + height - round(290 * scale)
    right = x + round(215 * scale)
    bottom = target_y + half_band + 1
    capture = (left, top, right, bottom)
    liquid = (
        0,
        target_y - half_band - top,
        round(130 * scale),
        bottom - top,
    )
    # This gold upper rim remains visible regardless of the amount of life.
    anchor = (
        round(15 * scale),
        round(5 * scale),
        round(135 * scale),
        round(30 * scale),
    )
    return capture, liquid, anchor


def parse_life(text: str, expected_max: int | None = None) -> tuple[int, int] | None:
    # Tesseract can insert newlines or confuse punctuation around the label.
    text = " ".join(text.split())
    match = LIFE_RE.search(text)
    if not match:
        return None
    try:
        current = int(re.sub(r"\D", "", match.group(1)))
        maximum_digits = re.sub(r"\D", "", match.group(2))
        # HUD ornamentation occasionally OCRs as 1-2 junk digits immediately
        # after the maximum. The configured max gives us a safe delimiter.
        if expected_max is not None and maximum_digits.startswith(str(expected_max)):
            maximum = expected_max
        else:
            maximum = int(maximum_digits)
    except ValueError:
        return None
    return current, maximum


class LifeReader:
    def __init__(self, crop: tuple[int, int, int, int], expected_max: int):
        self.crop = crop
        self.expected_max = expected_max
        self.last_text = ""

    def read(self) -> int | None:
        image = ImageGrab.grab(
            bbox=self.crop,
            xdisplay=os.environ.get("DISPLAY", ":0"),
        )
        # Upscaling preserves the game's antialiased glyphs better than thresholding.
        image = image.resize((image.width * 4, image.height * 4))
        encoded = io.BytesIO()
        image.save(encoded, format="PNG")
        command = [
            "tesseract",
            "stdin",
            "stdout",
            "--tessdata-dir",
            str(TESSDATA_DIR),
            "--psm",
            "6",
            "-c",
            "tessedit_char_whitelist=Life0123456789/,",
        ]
        process = subprocess.run(
            command, input=encoded.getvalue(), capture_output=True, timeout=2
        )
        if process.returncode != 0:
            detail = process.stderr.decode(errors="replace").strip()
            raise RuntimeError(f"Tesseract failed: {detail}")
        self.last_text = process.stdout.decode(errors="replace")
        parsed = parse_life(self.last_text, self.expected_max)
        if parsed is None:
            return None
        current, maximum = parsed
        # Requiring the known maximum discards nearly all dangerous OCR mistakes.
        if maximum != self.expected_max or not 0 <= current <= maximum:
            return None
        return current


class OrbThresholdReader:
    """Fast filled-vs-empty detector for one horizontal band in the life orb."""

    def __init__(
        self,
        crop: tuple[int, int, int, int],
        fps: int = 20,
        liquid_box: tuple[int, int, int, int] | None = None,
        anchor_box: tuple[int, int, int, int] | None = None,
    ):
        self.crop = crop
        left, top, right, bottom = crop
        self.width = right - left
        self.height = bottom - top
        self.frame_bytes = self.width * self.height * 3
        self.liquid_box = liquid_box or (0, 0, self.width, self.height)
        self.anchor_box = anchor_box
        display = os.environ.get("DISPLAY", ":0")
        command = [
            "ffmpeg", "-hide_banner", "-loglevel", "error",
            "-f", "x11grab", "-draw_mouse", "0",
            "-framerate", str(fps),
            "-video_size", f"{self.width}x{self.height}",
            "-i", f"{display}+{left},{top}",
            "-an", "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1",
        ]
        try:
            self.process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0
            )
        except OSError as exc:
            raise RuntimeError(f"could not start persistent X11 capture: {exc}") from exc

    def _frame(self) -> bytes:
        assert self.process.stdout is not None
        data = bytearray()
        while len(data) < self.frame_bytes:
            chunk = self.process.stdout.read(self.frame_bytes - len(data))
            if not chunk:
                detail = ""
                if self.process.stderr is not None:
                    detail = self.process.stderr.read().decode(errors="replace").strip()
                raise RuntimeError(f"X11 capture stopped unexpectedly: {detail}")
            data.extend(chunk)
        return bytes(data)

    @staticmethod
    def _liquid_score(image: Image.Image) -> float:
        image = image.convert("HSV")
        _hue, saturation, value = image.split()
        saturated = saturation.point(lambda pixel: 255 if pixel >= 60 else 0)
        visible = value.point(lambda pixel: 255 if pixel >= 45 else 0)
        # Count pixels that look like the colorful liquid used by the current globe skin.
        sat_data = saturated.tobytes()
        val_data = visible.tobytes()
        filled = sum(bool(a and b) for a, b in zip(sat_data, val_data))
        return filled / (image.width * image.height)

    @staticmethod
    def _rim_score(image: Image.Image) -> float:
        # Gold/brown rim: hue 13-65 degrees, moderately saturated and visible.
        gold = 0
        for hue, saturation, value in image.convert("HSV").getdata():
            if 9 <= hue <= 46 and saturation >= 64 and value >= 51:
                gold += 1
        return gold / (image.width * image.height)

    def read(self) -> tuple[float, float]:
        image = Image.frombytes("RGB", (self.width, self.height), self._frame())
        liquid = self._liquid_score(image.crop(self.liquid_box))
        presence = (
            self._rim_score(image.crop(self.anchor_box))
            if self.anchor_box is not None
            else 1.0
        )
        return liquid, presence

    def score(self) -> float:
        return self.read()[0]

    def calibrate(self, samples: int = 6) -> tuple[float, float]:
        liquid_readings = []
        presence_readings = []
        for _ in range(samples):
            liquid, presence = self.read()
            liquid_readings.append(liquid)
            presence_readings.append(presence)
        liquid_readings.sort()
        presence_readings.sort()
        middle = len(liquid_readings) // 2
        return liquid_readings[middle], presence_readings[middle]

    def close(self) -> None:
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=1)


def xp_bar_crop(screen: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    """Return the bottom HUD strip containing the experience bar."""
    x, y, width, height = screen
    scale = height / 1440
    # PoE lays out this part of the HUD from its 1440p reference canvas. The
    # visible XP track begins after the flask panel and contains twenty 55px
    # sections (5% each), even where the skill panel later overlaps it.
    left = x + round(734 * scale)
    return (
        left,
        y + height - round(60 * scale),
        min(x + width, left + round(1100 * scale)),
        y + height - max(1, round(5 * scale)),
    )


class XpBarReader:
    """Persistent X11 capture that measures the yellow XP fill boundary."""

    def __init__(self, crop: tuple[int, int, int, int], fps: int = 2):
        self.crop = crop
        left, top, right, bottom = crop
        self.width = right - left
        self.height = bottom - top
        self.frame_bytes = self.width * self.height * 3
        display = os.environ.get("DISPLAY", ":0")
        command = [
            "ffmpeg", "-hide_banner", "-loglevel", "error",
            "-f", "x11grab", "-draw_mouse", "0", "-framerate", str(fps),
            "-video_size", f"{self.width}x{self.height}",
            "-i", f"{display}+{left},{top}", "-an", "-pix_fmt", "rgb24",
            "-f", "rawvideo", "pipe:1",
        ]
        try:
            self.process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0
            )
        except OSError as exc:
            raise RuntimeError(f"could not start XP-bar capture: {exc}") from exc

    def _frame(self) -> Image.Image:
        assert self.process.stdout is not None
        data = bytearray()
        while len(data) < self.frame_bytes:
            chunk = self.process.stdout.read(self.frame_bytes - len(data))
            if not chunk:
                detail = ""
                if self.process.stderr is not None:
                    detail = self.process.stderr.read().decode(errors="replace").strip()
                raise RuntimeError(f"XP-bar capture stopped unexpectedly: {detail}")
            data.extend(chunk)
        return Image.frombytes("RGB", (self.width, self.height), bytes(data))

    @staticmethod
    def measure(image: Image.Image) -> float | None:
        """Measure the yellow XP boundary as a fractional percentage."""
        image = image.convert("RGB")
        width, height = image.size
        if width < 100 or height < 3:
            return None
        boundaries: list[int] = []
        max_gap = max(4, round(width * 0.009))
        for y in range(height):
            yellow: list[bool] = []
            for x in range(width):
                red, green, blue = image.getpixel((x, y))
                yellow.append(
                    red >= 90 and green >= 45
                    and red >= green * 1.25 and green >= blue * 1.20
                )
            try:
                start = next(
                    x for x in range(min(25, width)) if yellow[x]
                )
            except StopIteration:
                continue

            last_yellow = start
            gap = 0
            hits = 0
            for x in range(start, width):
                if yellow[x]:
                    last_yellow = x
                    gap = 0
                    hits += 1
                else:
                    gap += 1
                    if gap > max_gap:
                        break
            span = last_yellow - start + 1
            density = hits / span
            if density >= 0.70:
                boundaries.append(last_yellow + 1)

        if not boundaries:
            return None
        boundaries.sort()
        middle = len(boundaries) // 2
        boundary = (
            boundaries[middle]
            if len(boundaries) % 2
            else (boundaries[middle - 1] + boundaries[middle]) / 2
        )
        return boundary * 100 / width

    def read(self) -> float | None:
        return self.measure(self._frame())

    def close(self) -> None:
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=1)


@lru_cache(maxsize=1)
def builtin_wav() -> bytes:
    sample_rate = 44100
    samples: list[int] = []
    # Two prominent rising notes, with short fades to avoid clicks.
    for frequency in (400, 520):
        length = int(sample_rate * 0.16)
        for index in range(length):
            edge = min(index / 500, (length - index) / 500, 1.0)
            value = 0.30 * edge * math.sin(2 * math.pi * frequency * index / sample_rate)
            samples.append(round(32767 * value))
        samples.extend([0] * int(sample_rate * 0.05))
    output = io.BytesIO()
    with wave.open(output, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(struct.pack(f"<{len(samples)}h", *samples))
    return output.getvalue()


def play_sound(sound: str) -> None:
    def worker() -> None:
        try:
            if sound != "builtin":
                path = Path(sound).expanduser()
                if not path.is_file():
                    print(f"\nWarning: sound file does not exist: {path}", file=sys.stderr)
                    return
                if shutil.which("pw-play"):
                    subprocess.run(["pw-play", str(path)], stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL)
                elif shutil.which("ffplay"):
                    subprocess.run(["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
                                    str(path)], stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL)
                else:
                    print("\nWarning: install pw-play or ffplay to play a custom sound",
                          file=sys.stderr)
                return

            data = builtin_wav()
            if shutil.which("pw-play"):
                subprocess.run(["pw-play", "-"], input=data, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            elif shutil.which("aplay"):
                subprocess.run(["aplay", "-q"], input=data, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            elif shutil.which("ffplay"):
                subprocess.run(
                    ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", "-i", "pipe:0"],
                    input=data, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            else:
                print("\nWarning: no supported audio player found", file=sys.stderr)
        except OSError as exc:
            print(f"\nWarning: could not play alert: {exc}", file=sys.stderr)

    threading.Thread(target=worker, name="life-alert", daemon=True).start()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read Path of Exile life from the X11 HUD and sound a low-life alert."
    )
    parser.add_argument(
        "threshold", nargs="?",
        help="alert level as life (e.g. 1500) or percent (e.g. 40%%)"
    )
    parser.add_argument("--max-life", type=int, help="expected maximum life")
    parser.add_argument(
        "--screen", metavar="GEOMETRY",
        help="game screen as WIDTHxHEIGHT+X+Y (default: X11 primary screen)"
    )
    parser.add_argument("--sound", help="WAV/OGG/MP3 path, or 'builtin'")
    parser.add_argument("--interval", type=float, help="seconds between readings")
    parser.add_argument(
        "--detection", choices=("orb", "ocr"),
        help="fast orb-fill detection (default) or exact-number OCR"
    )
    parser.add_argument("--save", action="store_true", help="save supplied settings to config.json")
    parser.add_argument("--once", action="store_true", help="print one valid reading and exit")
    parser.add_argument("--show-crop", metavar="PNG", help="save the OCR region for troubleshooting")
    parser.add_argument("--test-sound", action="store_true", help="play the alert and exit")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    config = load_config()

    if args.max_life is not None:
        if args.max_life < 2:
            parser.error("--max-life must be at least 2")
        config["max_life"] = args.max_life
    if args.threshold is not None:
        try:
            config["threshold"] = parse_threshold(args.threshold, int(config["max_life"]))
        except argparse.ArgumentTypeError as exc:
            parser.error(str(exc))
    if args.screen is not None:
        try:
            parse_geometry(args.screen)
        except ValueError as exc:
            parser.error(f"--screen: {exc}")
        config["screen"] = args.screen
    if args.sound is not None:
        config["sound"] = args.sound
    if args.interval is not None:
        if not 0.1 <= args.interval <= 10:
            parser.error("--interval must be between 0.1 and 10 seconds")
        config["interval_seconds"] = args.interval
    if args.detection is not None:
        config["detection"] = args.detection

    max_life = int(config["max_life"])
    threshold = int(config["threshold"])
    if not 0 < threshold < max_life:
        parser.error(f"configured threshold must be between 1 and {max_life - 1}")

    if args.save:
        save_config(config)
        print(f"Saved settings to {CONFIG_PATH}")

    if args.test_sound:
        play_sound(str(config["sound"]))
        time.sleep(1)
        return 0

    screen = primary_screen() if config["screen"] == "auto" else parse_geometry(config["screen"])
    detection = str(config.get("detection", "orb"))
    orb_geometry = orb_capture_geometry(screen, threshold / max_life)
    crop = orb_geometry[0] if detection == "orb" else life_crop(screen)

    if args.show_crop:
        ImageGrab.grab(bbox=crop, xdisplay=os.environ.get("DISPLAY", ":0")).save(args.show_crop)
        print(f"Saved OCR crop to {args.show_crop}")
        return 0

    interval = float(config["interval_seconds"])
    confirmations = max(1, int(config["confirm_readings"]))
    rearm_at = min(max_life, threshold + round(max_life * float(config["rearm_percent"]) / 100))

    print(f"PoE life monitor: alert at {threshold:,}/{max_life:,} "
          f"({threshold / max_life:.0%})")
    print(f"Screen: {screen[2]}x{screen[3]}+{screen[0]}+{screen[1]}  "
          f"Detection: {detection}  Ctrl+C to stop")

    if detection == "orb":
        if not shutil.which("ffmpeg"):
            raise SystemExit("ffmpeg with x11grab support is required for fast orb detection")
        reader = OrbThresholdReader(
            crop,
            int(config.get("capture_fps", 20)),
            liquid_box=orb_geometry[1],
            anchor_box=orb_geometry[2],
        )
        try:
            print("Calibrating orb (life must currently be above the alert threshold)...")
            baseline, presence_baseline = reader.calibrate()
            if baseline < 0.20 or presence_baseline < 0.05:
                raise SystemExit(
                    "Could not see the filled life orb and its upper rim. "
                    "Keep life above the threshold and the orb unobscured, or use --detection ocr."
                )
            empty_at = baseline * float(config.get("orb_empty_ratio", 0.55))
            rearm_score = baseline * 0.75
            hud_visible_at = presence_baseline * float(config.get("hud_presence_ratio", 0.55))
            hud_return_frames = max(1, int(config.get("hud_return_frames", 10)))
            print(f"Ready: orb signal {baseline:.0%}; low-life boundary {empty_at:.0%}")

            low_reads = 0
            armed = True
            hud_missing = False
            visible_reads = hud_return_frames
            while True:
                score, presence = reader.read()
                if presence < hud_visible_at:
                    low_reads = 0
                    visible_reads = 0
                    if not hud_missing:
                        print("\nHUD hidden/loading — alerts paused")
                    hud_missing = True
                    continue
                if hud_missing:
                    visible_reads += 1
                    if visible_reads < hud_return_frames:
                        continue
                    hud_missing = False
                    print("\nHUD visible — alerts resumed")
                print(f"\rOrb at alert level: {score:.0%} filled signal".ljust(79),
                      end="", flush=True)
                if args.once:
                    print()
                    return 0
                if score <= empty_at:
                    low_reads += 1
                    if armed and low_reads >= confirmations:
                        print(f"\nLOW LIFE: crossed {threshold:,}/{max_life:,}")
                        play_sound(str(config["sound"]))
                        armed = False
                else:
                    low_reads = 0
                    if score >= rearm_score:
                        armed = True
        except KeyboardInterrupt:
            print("\nStopped.")
            return 0
        finally:
            reader.close()

    if not shutil.which("tesseract"):
        raise SystemExit("tesseract is not installed")
    if not (TESSDATA_DIR / "eng.traineddata").is_file():
        raise SystemExit(f"missing {TESSDATA_DIR / 'eng.traineddata'}")

    reader = LifeReader(crop, max_life)

    armed = True
    low_reads = 0
    failures = 0
    try:
        while True:
            started = time.monotonic()
            current = reader.read()
            if current is None:
                failures += 1
                if failures % 15 == 0:
                    print("\rWaiting for a readable Life value (is the HUD visible?)".ljust(79),
                          end="", flush=True)
            else:
                failures = 0
                percent = current / max_life
                print(f"\rLife {current:,}/{max_life:,} ({percent:5.1%})".ljust(79),
                      end="", flush=True)
                if args.once:
                    print()
                    return 0
                if current <= threshold:
                    low_reads += 1
                    if armed and low_reads >= confirmations:
                        print(f"\nLOW LIFE: {current:,} <= {threshold:,}")
                        play_sound(str(config["sound"]))
                        armed = False
                else:
                    low_reads = 0
                    if current >= rearm_at:
                        armed = True

            elapsed = time.monotonic() - started
            time.sleep(max(0, interval - elapsed))
    except KeyboardInterrupt:
        print("\nStopped.")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
