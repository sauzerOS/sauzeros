#!/usr/bin/env python3
"""Turn Shift+wheel into Ctrl+left-click while Path of Exile is focused.

The implementation uses an X11 passive button grab.  A matching wheel event is
only consumed for a Path of Exile window; for every other window it is replayed
unchanged.  Each wheel notch produces exactly one synthetic left click.
"""

from __future__ import annotations

import ctypes
from ctypes.util import find_library
import os
import threading
import time


ButtonPress = 4
ButtonPressMask = 1 << 2
GrabModeSync = 0
GrabModeAsync = 1
ReplayPointer = 2
CurrentTime = 0
ControlMask = 1 << 2
ShiftMask = 1 << 0
LockMask = 1 << 1
Mod2Mask = 1 << 4
AnyPropertyType = 0
Success = 0


class XButtonEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("serial", ctypes.c_ulong),
        ("send_event", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("window", ctypes.c_ulong),
        ("root", ctypes.c_ulong),
        ("subwindow", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("x", ctypes.c_int),
        ("y", ctypes.c_int),
        ("x_root", ctypes.c_int),
        ("y_root", ctypes.c_int),
        ("state", ctypes.c_uint),
        ("button", ctypes.c_uint),
        ("same_screen", ctypes.c_int),
    ]


class XEvent(ctypes.Union):
    # XEvent is 24 longs on every supported Xlib ABI.
    _fields_ = [("type", ctypes.c_int), ("xbutton", XButtonEvent),
                ("pad", ctypes.c_long * 24)]


class XClassHint(ctypes.Structure):
    _fields_ = [("res_name", ctypes.c_void_p), ("res_class", ctypes.c_void_p)]


class X11ScrollClick:
    """X11 listener implementing the one-wheel-notch-to-one-click mapping."""

    WHEEL_BUTTONS = (4, 5)
    LOCK_COMBINATIONS = (0, LockMask, Mod2Mask, LockMask | Mod2Mask)
    POE_IDENTIFIERS = ("pathofexile", "path of exile", "steam_app_238960")

    def __init__(self) -> None:
        x11_name = find_library("X11")
        xtst_name = find_library("Xtst")
        if not x11_name or not xtst_name:
            raise RuntimeError("libX11 and libXtst are required for scroll-click")
        self.x11 = ctypes.CDLL(x11_name)
        self.xtst = ctypes.CDLL(xtst_name)
        self._declare_functions()
        self.display: int | None = None
        self.root = 0
        self.active_window_atom = 0

    def _declare_functions(self) -> None:
        self.x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
        self.x11.XOpenDisplay.restype = ctypes.c_void_p
        self.x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
        self.x11.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
        self.x11.XDefaultRootWindow.restype = ctypes.c_ulong
        self.x11.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
        self.x11.XInternAtom.restype = ctypes.c_ulong
        self.x11.XGrabButton.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_ulong,
            ctypes.c_int, ctypes.c_uint, ctypes.c_int, ctypes.c_int,
            ctypes.c_ulong, ctypes.c_ulong,
        ]
        self.x11.XUngrabButton.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_ulong
        ]
        self.x11.XUngrabPointer.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        self.x11.XAllowEvents.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ulong]
        self.x11.XPending.argtypes = [ctypes.c_void_p]
        self.x11.XPending.restype = ctypes.c_int
        self.x11.XNextEvent.argtypes = [ctypes.c_void_p, ctypes.POINTER(XEvent)]
        self.x11.XFlush.argtypes = [ctypes.c_void_p]
        self.x11.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self.x11.XQueryKeymap.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.x11.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        self.x11.XKeysymToKeycode.restype = ctypes.c_ubyte
        self.x11.XGetWindowProperty.argtypes = [
            ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_long,
            ctypes.c_long, ctypes.c_int, ctypes.c_ulong,
            ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_ulong),
            ctypes.POINTER(ctypes.c_void_p),
        ]
        self.x11.XGetWindowProperty.restype = ctypes.c_int
        self.x11.XGetClassHint.argtypes = [
            ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(XClassHint)
        ]
        self.x11.XGetClassHint.restype = ctypes.c_int
        self.x11.XFetchName.argtypes = [
            ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_void_p)
        ]
        self.x11.XFetchName.restype = ctypes.c_int
        self.x11.XFree.argtypes = [ctypes.c_void_p]
        self.xtst.XTestFakeButtonEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong
        ]
        self.xtst.XTestFakeButtonEvent.restype = ctypes.c_int
        self.xtst.XTestFakeKeyEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong
        ]
        self.xtst.XTestFakeKeyEvent.restype = ctypes.c_int

    def _open(self) -> None:
        display_name = os.environ.get("DISPLAY", ":0").encode()
        self.display = self.x11.XOpenDisplay(display_name)
        if not self.display:
            raise RuntimeError(f"could not open X11 display {display_name.decode()}")
        self.root = self.x11.XDefaultRootWindow(self.display)
        self.active_window_atom = self.x11.XInternAtom(
            self.display, b"_NET_ACTIVE_WINDOW", False
        )

    def _active_window(self) -> int:
        assert self.display is not None
        actual_type = ctypes.c_ulong()
        actual_format = ctypes.c_int()
        item_count = ctypes.c_ulong()
        bytes_after = ctypes.c_ulong()
        value = ctypes.c_void_p()
        result = self.x11.XGetWindowProperty(
            self.display, self.root, self.active_window_atom, 0, 1, False,
            AnyPropertyType, ctypes.byref(actual_type), ctypes.byref(actual_format),
            ctypes.byref(item_count), ctypes.byref(bytes_after), ctypes.byref(value),
        )
        try:
            if result != Success or not value.value or item_count.value < 1:
                return 0
            return int(ctypes.cast(value, ctypes.POINTER(ctypes.c_ulong))[0])
        finally:
            if value.value:
                self.x11.XFree(value)

    def _window_identity(self, window: int) -> str:
        assert self.display is not None
        parts: list[str] = []
        hint = XClassHint()
        if window and self.x11.XGetClassHint(self.display, window, ctypes.byref(hint)):
            try:
                for pointer in (hint.res_name, hint.res_class):
                    if pointer:
                        parts.append(ctypes.string_at(pointer).decode(errors="replace"))
            finally:
                if hint.res_name:
                    self.x11.XFree(hint.res_name)
                if hint.res_class:
                    self.x11.XFree(hint.res_class)
        name = ctypes.c_void_p()
        if window and self.x11.XFetchName(self.display, window, ctypes.byref(name)):
            try:
                if name.value:
                    parts.append(ctypes.string_at(name).decode(errors="replace"))
            finally:
                if name.value:
                    self.x11.XFree(name)
        return " ".join(parts).lower()

    def _poe_is_active(self) -> bool:
        identity = self._window_identity(self._active_window())
        return any(marker in identity for marker in self.POE_IDENTIFIERS)

    def open(self) -> None:
        if self.display is None:
            self._open()

    def is_poe_active(self) -> bool:
        if self.display is None:
            raise RuntimeError("X11 display is not open")
        return self._poe_is_active()

    def close(self) -> None:
        if self.display is not None:
            self.x11.XCloseDisplay(self.display)
            self.display = None

    def _grab(self) -> None:
        assert self.display is not None
        for button in self.WHEEL_BUTTONS:
            for locks in self.LOCK_COMBINATIONS:
                self.x11.XGrabButton(
                    self.display, button, ShiftMask | locks, self.root, False,
                    ButtonPressMask, GrabModeSync, GrabModeAsync, 0, 0,
                )
        self.x11.XSync(self.display, False)

    def _ungrab(self) -> None:
        if not self.display:
            return
        for button in self.WHEEL_BUTTONS:
            for locks in self.LOCK_COMBINATIONS:
                self.x11.XUngrabButton(
                    self.display, button, ShiftMask | locks, self.root
                )
        self.x11.XSync(self.display, False)

    def _pressed_shift_keycodes(self) -> list[int]:
        assert self.display is not None
        # XK_Shift_L and XK_Shift_R. Querying the keymap lets us restore only
        # the physical Shift key the user is actually holding.
        shift_keycodes = [
            int(self.x11.XKeysymToKeycode(self.display, keysym))
            for keysym in (0xFFE1, 0xFFE2)
        ]
        keymap = (ctypes.c_char * 32)()
        self.x11.XQueryKeymap(self.display, keymap)
        pressed = ctypes.string_at(keymap, 32)
        return [
            keycode for keycode in shift_keycodes
            if keycode and pressed[keycode // 8] & (1 << (keycode % 8))
        ]

    def _ctrl_click(self) -> None:
        assert self.display is not None
        # End the active wheel grab before injecting Button1 so the click is
        # delivered to PoE rather than back to this listener.
        self.x11.XUngrabPointer(self.display, CurrentTime)
        active_shifts = self._pressed_shift_keycodes()
        control_keycode = int(self.x11.XKeysymToKeycode(self.display, 0xFFE3))
        # Shift is the trigger, but it must not reach PoE as part of the click.
        # Temporarily release the held Shift key, perform Ctrl+click, and restore
        # Shift so continued wheel movement remains active.
        for keycode in active_shifts:
            self.xtst.XTestFakeKeyEvent(self.display, keycode, False, CurrentTime)
        self.xtst.XTestFakeKeyEvent(self.display, control_keycode, True, CurrentTime)
        self.xtst.XTestFakeButtonEvent(self.display, 1, True, CurrentTime)
        self.xtst.XTestFakeButtonEvent(self.display, 1, False, CurrentTime)
        self.xtst.XTestFakeKeyEvent(self.display, control_keycode, False, CurrentTime)
        for keycode in active_shifts:
            self.xtst.XTestFakeKeyEvent(self.display, keycode, True, CurrentTime)
        self.x11.XFlush(self.display)

    def run(self, stop: threading.Event) -> None:
        self._open()
        self._grab()
        event = XEvent()
        try:
            while not stop.is_set():
                if not self.x11.XPending(self.display):
                    time.sleep(0.01)
                    continue
                self.x11.XNextEvent(self.display, ctypes.byref(event))
                if event.type != ButtonPress or event.xbutton.button not in self.WHEEL_BUTTONS:
                    self.x11.XAllowEvents(self.display, ReplayPointer, CurrentTime)
                    continue
                if self._poe_is_active():
                    self._ctrl_click()
                else:
                    # Let Shift+wheel behave normally outside the game.
                    self.x11.XAllowEvents(self.display, ReplayPointer, CurrentTime)
                    self.x11.XFlush(self.display)
        finally:
            self._ungrab()
            self.close()
