#!/usr/bin/env python3
"""Small PyQt6 front end for the Path of Exile life monitor."""

from __future__ import annotations

import sys
import threading
import time
from collections import deque
from math import ceil
from statistics import median

from PyQt6.QtCore import QThread, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QCloseEvent, QIcon, QMouseEvent
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QCheckBox,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

import poe_life_monitor as core
from x11_scroll_click import X11ScrollClick


def xp_display_percent(percent: float) -> int:
    """Match PoE's whole-percent display for fractional bar progress."""
    return min(100, max(0, ceil(percent)))


def top_right_position(
    screen_x: int, screen_y: int, screen_width: int, window_width: int
) -> tuple[int, int]:
    """Place a window flush with the top-right corner of a screen."""
    return screen_x + screen_width - window_width, screen_y


class MonitorWorker(QThread):
    status_changed = pyqtSignal(str, str)
    score_changed = pyqtSignal(int)
    alert_triggered = pyqtSignal(int)
    failed = pyqtSignal(str)

    def __init__(self, maximum: int, percent: int, config: dict):
        super().__init__()
        self.maximum = maximum
        self.percent = percent
        self.threshold = round(maximum * percent / 100)
        self.config = config
        self._stop_requested = threading.Event()

    def request_stop(self) -> None:
        self._stop_requested.set()

    def run(self) -> None:
        reader = None
        focus_monitor = None
        try:
            self.status_changed.emit("calibrating", "Calibrating orb…")
            if str(self.config.get("sound", "builtin")) == "builtin":
                # Construct and cache the waveform now, not at the critical alert moment.
                core.builtin_wav()
            screen_setting = self.config.get("screen", "auto")
            screen = (
                core.primary_screen()
                if screen_setting == "auto"
                else core.parse_geometry(str(screen_setting))
            )
            crop, liquid_box, anchor_box = core.orb_capture_geometry(
                screen, self.percent / 100
            )
            reader = core.OrbThresholdReader(
                crop,
                int(self.config.get("capture_fps", 20)),
                liquid_box=liquid_box,
                anchor_box=anchor_box,
            )
            baseline, presence_baseline = reader.calibrate()
            if baseline < 0.20 or presence_baseline < 0.05:
                raise RuntimeError(
                    "The filled orb and its upper rim were not visible. "
                    "Start while life is above the alert percentage and keep the HUD visible."
                )

            empty_at = baseline * float(self.config.get("orb_empty_ratio", 0.55))
            rearm_score = baseline * 0.75
            hud_visible_at = presence_baseline * float(
                self.config.get("hud_presence_ratio", 0.55)
            )
            hud_return_frames = max(1, int(self.config.get("hud_return_frames", 10)))
            confirmations = max(1, int(self.config.get("confirm_readings", 2)))
            low_reads = 0
            armed = True
            hud_missing = False
            visible_reads = hud_return_frames
            self.status_changed.emit(
                "running",
                f"Monitoring — alert at {self.percent}% ({self.threshold:,} life)",
            )

            while not self._stop_requested.is_set():
                score, presence = reader.read()
                normalized = max(0, min(100, round(score / baseline * 100)))
                self.score_changed.emit(normalized)

                if presence < hud_visible_at:
                    low_reads = 0
                    visible_reads = 0
                    if not hud_missing:
                        self.status_changed.emit(
                            "calibrating", "Loading screen — alerts paused"
                        )
                    hud_missing = True
                    continue

                if hud_missing:
                    visible_reads += 1
                    if visible_reads < hud_return_frames:
                        continue
                    hud_missing = False
                    self.status_changed.emit(
                        "running",
                        f"Monitoring — alert at {self.percent}% ({self.threshold:,} life)",
                    )

                if score <= empty_at:
                    low_reads += 1
                    if armed and low_reads >= confirmations:
                        armed = False
                        self.alert_triggered.emit(self.threshold)
                        core.play_sound(str(self.config.get("sound", "builtin")))
                        self.status_changed.emit(
                            "alert", f"Low life — crossed {self.percent}%"
                        )
                else:
                    low_reads = 0
                    if not armed and score >= rearm_score:
                        armed = True
                        self.status_changed.emit(
                            "running",
                            f"Monitoring — alert at {self.percent}% ({self.threshold:,} life)",
                        )
        except Exception as exc:
            if not self._stop_requested.is_set():
                self.failed.emit(str(exc))
        finally:
            if reader is not None:
                reader.close()


class ScrollClickWorker(QThread):
    failed = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._stop_requested = threading.Event()

    def request_stop(self) -> None:
        self._stop_requested.set()

    def run(self) -> None:
        try:
            X11ScrollClick().run(self._stop_requested)
        except Exception as exc:
            if not self._stop_requested.is_set():
                self.failed.emit(str(exc))


class XpWorker(QThread):
    updated = pyqtSignal(str, str, str)
    failed = pyqtSignal(str)

    def __init__(self, config: dict):
        super().__init__()
        self.config = config
        self._stop_requested = threading.Event()

    def request_stop(self) -> None:
        self._stop_requested.set()

    @staticmethod
    def _eta_text(hours: float) -> str:
        minutes = max(0, round(hours * 60))
        if minutes < 60:
            return f"{minutes} min"
        return f"{minutes // 60}h {minutes % 60:02d}m"

    def run(self) -> None:
        reader = None
        try:
            screen_setting = self.config.get("screen", "auto")
            screen = (
                core.primary_screen()
                if screen_setting == "auto"
                else core.parse_geometry(str(screen_setting))
            )
            reader = core.XpBarReader(core.xp_bar_crop(screen), fps=2)
            focus_monitor = X11ScrollClick()
            focus_monitor.open()
            recent: deque[float] = deque(maxlen=8)
            history: deque[tuple[float, float]] = deque()
            last_percent: float | None = None
            level_offset = 0.0
            missing = 0
            calibrated = False
            while not self._stop_requested.is_set():
                measured = reader.read()
                if not focus_monitor.is_poe_active():
                    recent.clear()
                    calibrated = False
                    missing += 1
                    if missing == 10:
                        self.updated.emit("Waiting for PoE…", "—", "—")
                    continue
                if measured is None:
                    missing += 1
                    if missing == 1:
                        # Do not blend pre-loading-screen samples with the first
                        # frames after the HUD returns.
                        recent.clear()
                        calibrated = False
                    if missing == 10:
                        self.updated.emit("Waiting for XP bar…", "—", "—")
                    continue
                missing = 0
                recent.append(measured)
                if not calibrated:
                    if len(recent) < recent.maxlen:
                        continue
                    if max(recent) - min(recent) > 0.35:
                        continue
                    calibrated = True
                if len(recent) < 3:
                    continue
                percent = median(recent)
                display_percent = xp_display_percent(percent)
                now = time.monotonic()
                if last_percent is not None and last_percent >= 90 and percent <= 10:
                    level_offset += 100
                    history.clear()
                last_percent = percent
                cumulative = level_offset + percent
                history.append((now, cumulative))
                while history and history[0][0] < now - 600:
                    history.popleft()

                rate_text = "Collecting…"
                eta_text = "—"
                if len(history) >= 2:
                    elapsed = history[-1][0] - history[0][0]
                    if elapsed >= 60:
                        # Average the beginning and end of the sample range so a
                        # one-pixel animated edge cannot dominate the result.
                        edge_window = min(20.0, elapsed / 3)
                        start_points = [
                            point for point in history
                            if point[0] <= history[0][0] + edge_window
                        ]
                        end_points = [
                            point for point in history
                            if point[0] >= history[-1][0] - edge_window
                        ]
                        start_time = median(point[0] for point in start_points)
                        end_time = median(point[0] for point in end_points)
                        start_xp = median(point[1] for point in start_points)
                        end_xp = median(point[1] for point in end_points)
                        rate = (end_xp - start_xp) * 3600 / (end_time - start_time)
                        rate_text = f"{rate:.1f}%/h"
                        if rate > 0:
                            eta_text = self._eta_text((100 - percent) / rate)
                self.updated.emit(f"{display_percent}%", rate_text, eta_text)
        except Exception as exc:
            if not self._stop_requested.is_set():
                self.failed.emit(str(exc))
        finally:
            if reader is not None:
                reader.close()
            if focus_monitor is not None:
                focus_monitor.close()


class XpWindow(QWidget):
    """Compact override-redirect X11 overlay kept above the game."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("PoE XP Tracker")
        self.setWindowIcon(QIcon(str(core.APP_DIR / "poe-life-monitor.svg")))
        self.setWindowFlags(
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.X11BypassWindowManagerHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setObjectName("xpOverlay")
        self.setFixedSize(460, 105)
        self.setWindowOpacity(0.82)
        self.setToolTip("Drag to move; right-click to hide")
        self._drag_offset = None
        self._positioned = False

        self.raise_timer = QTimer(self)
        self.raise_timer.timeout.connect(self._keep_above)
        self.raise_timer.start(500)

        layout = QGridLayout(self)
        layout.setContentsMargins(16, 11, 16, 12)
        layout.setHorizontalSpacing(18)
        headings = ("Current XP", "XP rate (10 min)", "Next level ETA")
        for column, text in enumerate(headings):
            heading = QLabel(text)
            heading.setObjectName("xpHeading")
            heading.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(heading, 0, column)

        self.percent_label = QLabel("Waiting for XP bar…")
        self.rate_label = QLabel("—")
        self.eta_label = QLabel("—")
        for column, label in enumerate(
            (self.percent_label, self.rate_label, self.eta_label)
        ):
            label.setObjectName("xpValue")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(label, 1, column)

        self.setStyleSheet(
            """
            QWidget#xpOverlay { background: #17191d; border: 1px solid #68604e; }
            QLabel { background: transparent; border: none; color: #e7e2d8; }
            QLabel#xpHeading { color: #a8abb2; font-size: 11px; }
            QLabel#xpValue { color: #f0c977; font-size: 16px; font-weight: 600; }
            """
        )

    def update_display(self, percent: str, rate: str, eta: str) -> None:
        self.percent_label.setText(percent)
        self.rate_label.setText(rate)
        self.eta_label.setText(eta)

    def position_at_top_right(self) -> None:
        """Set the initial position without overriding later user dragging."""
        if self._positioned:
            return
        screen = QApplication.primaryScreen()
        if screen is not None:
            geometry = screen.geometry()
            x, y = top_right_position(
                geometry.x(), geometry.y(), geometry.width(), self.width()
            )
            self.move(x, y)
        self._positioned = True

    def _keep_above(self) -> None:
        if self.isVisible():
            # With X11BypassWindowManagerHint this maps to an override-redirect
            # window; periodically raising it also handles Wine re-stacking PoE.
            self.raise_()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.RightButton:
            self.hide()
            event.accept()
            return
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = (
                event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            )
            event.accept()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if (
            self._drag_offset is not None
            and event.buttons() & Qt.MouseButton.LeftButton
        ):
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        self._drag_offset = None
        event.accept()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = core.load_config()
        self.worker: MonitorWorker | None = None
        self.scroll_worker: ScrollClickWorker | None = None
        self.xp_worker: XpWorker | None = None
        self.xp_window = XpWindow()
        # Keep Python references until window teardown. Releasing a QThread from
        # its own finished signal can race Qt's final native-thread cleanup.
        self.retired_workers: list[QThread] = []

        self.setWindowTitle("PoE Life Monitor")
        self.setWindowIcon(QIcon(str(core.APP_DIR / "poe-life-monitor.svg")))
        # Leave enough vertical room for the settings card, including the
        # scroll-transfer toggle, at the default font scale.
        self.setMinimumSize(540, 450)
        self.resize(580, 470)

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(16)

        title = QLabel("Path of Exile Life Monitor")
        title.setObjectName("title")
        subtitle = QLabel("Fast X11 orb monitoring")
        subtitle.setObjectName("subtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        settings = QFrame()
        settings.setObjectName("card")
        grid = QGridLayout(settings)
        grid.setContentsMargins(16, 14, 16, 14)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(12)

        maximum = int(self.config.get("max_life", 3144))
        saved_threshold = int(self.config.get("threshold", maximum // 2))
        saved_percent = int(
            self.config.get("gui_threshold_percent", round(saved_threshold / maximum * 100))
        )

        self.percent_box = QSpinBox()
        self.percent_box.setRange(5, 95)
        self.percent_box.setSuffix(" %")
        self.percent_box.setValue(saved_percent)
        self.percent_box.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.percent_box.setMinimumWidth(170)
        self.percent_box.setMinimumHeight(36)

        self.maximum_box = QSpinBox()
        self.maximum_box.setRange(2, 100000)
        self.maximum_box.setGroupSeparatorShown(True)
        self.maximum_box.setValue(maximum)
        self.maximum_box.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.maximum_box.setMinimumWidth(170)
        self.maximum_box.setMinimumHeight(36)

        grid.addWidget(QLabel("Alert below"), 0, 0)
        grid.addWidget(self.percent_box, 0, 1)
        grid.addWidget(QLabel("Maximum life"), 1, 0)
        grid.addWidget(self.maximum_box, 1, 1)
        self.threshold_preview = QLabel()
        self.threshold_preview.setObjectName("thresholdPreview")
        grid.addWidget(self.threshold_preview, 2, 0, 1, 2)

        self.scroll_click_box = QCheckBox(
            "Shift + mouse wheel transfers items (PoE only)"
        )
        self.scroll_click_box.setChecked(
            bool(
                self.config.get("shift_wheel_stash", False)
                or self.config.get("ctrl_wheel_stash", False)
            )
        )
        self.scroll_click_box.setToolTip(
            "While Path of Exile is focused, each Shift+wheel notch becomes one "
            "Ctrl+left-click at the pointer."
        )
        grid.addWidget(self.scroll_click_box, 3, 0, 1, 2)
        layout.addWidget(settings)

        status_row = QHBoxLayout()
        self.status_dot = QLabel("●")
        self.status_dot.setObjectName("stoppedDot")
        self.status_label = QLabel("Stopped")
        self.status_label.setWordWrap(True)
        self.status_label.setMinimumHeight(34)
        status_row.addWidget(self.status_dot)
        status_row.addWidget(self.status_label, 1)
        layout.addLayout(status_row)

        self.signal_bar = QProgressBar()
        self.signal_bar.setRange(0, 100)
        self.signal_bar.setValue(0)
        self.signal_bar.setFormat("Orb signal — %p%")
        layout.addWidget(self.signal_bar)

        buttons = QHBoxLayout()
        self.start_button = QPushButton("Start")
        self.start_button.setObjectName("startButton")
        self.stop_button = QPushButton("Stop")
        self.stop_button.setEnabled(False)
        self.apply_button = QPushButton("Apply")
        self.xp_button = QPushButton("XP window")
        self.test_button = QPushButton("Test sound")
        buttons.addWidget(self.start_button)
        buttons.addWidget(self.stop_button)
        buttons.addWidget(self.apply_button)
        buttons.addWidget(self.xp_button)
        buttons.addStretch()
        buttons.addWidget(self.test_button)
        layout.addLayout(buttons)

        hint = QLabel("Start while life is above the alert percentage.")
        hint.setObjectName("hint")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint)

        self.start_button.clicked.connect(self.start_monitoring)
        self.stop_button.clicked.connect(self.stop_monitoring)
        self.apply_button.clicked.connect(self.apply_settings)
        self.xp_button.clicked.connect(self.show_xp_window)
        self.test_button.clicked.connect(self.test_sound)
        self.percent_box.valueChanged.connect(self.settings_changed)
        self.maximum_box.valueChanged.connect(self.settings_changed)
        self.scroll_click_box.toggled.connect(self.set_scroll_click_enabled)
        self.update_threshold_preview()
        self._apply_style()
        if self.scroll_click_box.isChecked():
            QTimer.singleShot(0, lambda: self.set_scroll_click_enabled(True))
        QTimer.singleShot(0, self.show_xp_window)
        QTimer.singleShot(0, self.start_xp_tracking)

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow, QWidget { background: #17191d; color: #e7e2d8; font-size: 14px; }
            QLabel#title { font-size: 21px; font-weight: 700; color: #f0c977; }
            QLabel#subtitle, QLabel#hint { color: #8f949d; font-size: 12px; }
            QLabel#thresholdPreview { color: #d5b66e; padding-top: 4px; }
            QFrame#card { background: #22252b; border: 1px solid #343840; border-radius: 8px; }
            QSpinBox { background: #121418; border: 1px solid #464b55; border-radius: 5px;
                       padding: 6px 8px; min-width: 110px; }
            QCheckBox { color: #d9d4ca; padding-top: 5px; }
            QPushButton { background: #30343c; border: 1px solid #484d57; border-radius: 6px;
                          padding: 7px 15px; }
            QPushButton:hover { background: #3a3f48; }
            QPushButton:disabled { color: #686d75; background: #24272c; }
            QPushButton#startButton { background: #376849; border-color: #4d8b63; }
            QPushButton#startButton:hover { background: #407a55; }
            QLabel#stoppedDot { color: #777d86; }
            QLabel#runningDot { color: #57c878; }
            QLabel#calibratingDot { color: #e2b857; }
            QLabel#alertDot { color: #e25a5a; }
            QProgressBar { background: #101216; border: 1px solid #343840; border-radius: 5px;
                           height: 16px; text-align: center; color: #e7e2d8; }
            QProgressBar::chunk { background: #8b3434; border-radius: 4px; }
            """
        )

    def set_status(self, state: str, text: str) -> None:
        self.status_dot.setObjectName(f"{state}Dot")
        self.status_dot.style().unpolish(self.status_dot)
        self.status_dot.style().polish(self.status_dot)
        self.status_label.setText(text)

    def save_settings(self) -> tuple[int, int]:
        maximum = self.maximum_box.value()
        percent = self.percent_box.value()
        self.config["max_life"] = maximum
        self.config["threshold"] = round(maximum * percent / 100)
        self.config["gui_threshold_percent"] = percent
        self.config["detection"] = "orb"
        core.save_config(self.config)
        return maximum, percent

    def update_threshold_preview(self) -> None:
        maximum = self.maximum_box.value()
        percent = self.percent_box.value()
        threshold = round(maximum * percent / 100)
        self.threshold_preview.setText(
            f"Alert threshold: {threshold:,} life ({percent}% of {maximum:,})"
        )

    def settings_changed(self) -> None:
        self.update_threshold_preview()
        if self.worker is not None and self.worker.isRunning():
            self.set_status("calibrating", "Settings changed — click Apply to restart")

    def apply_settings(self) -> None:
        self.save_settings()
        if self.worker is not None and self.worker.isRunning():
            self.stop_monitoring(restart=True)
        else:
            self.set_status("stopped", "Settings saved")

    def start_monitoring(self) -> None:
        if self.worker is not None and self.worker.isRunning():
            return
        maximum, percent = self.save_settings()
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.signal_bar.setValue(0)

        self.worker = MonitorWorker(maximum, percent, dict(self.config))
        self.worker.status_changed.connect(self.set_status)
        self.worker.score_changed.connect(self.signal_bar.setValue)
        self.worker.failed.connect(self.monitor_failed)
        self.worker.finished.connect(self.monitor_finished)
        self.worker.start()

    def stop_monitoring(self, checked: bool = False, restart: bool = False) -> None:
        if self.worker is not None:
            self.set_status("calibrating", "Stopping…")
            self.stop_button.setEnabled(False)
            if restart:
                # Run after the old capture thread has fully released FFmpeg/X11.
                self.worker.setProperty("restartAfterStop", True)
            self.worker.request_stop()

    def monitor_failed(self, message: str) -> None:
        QMessageBox.warning(self, "Monitor stopped", message)

    def monitor_finished(self) -> None:
        restart = bool(
            self.worker is not None and self.worker.property("restartAfterStop")
        )
        if self.worker is not None:
            self.retired_workers.append(self.worker)
        self.worker = None
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.signal_bar.setValue(0)
        self.set_status("stopped", "Stopped")
        if restart:
            QTimer.singleShot(50, self.start_monitoring)

    def test_sound(self) -> None:
        core.play_sound(str(self.config.get("sound", "builtin")))

    def set_scroll_click_enabled(self, enabled: bool) -> None:
        self.config["shift_wheel_stash"] = enabled
        self.config.pop("ctrl_wheel_stash", None)
        core.save_config(self.config)
        if enabled:
            if self.scroll_worker is not None and self.scroll_worker.isRunning():
                return
            self.scroll_worker = ScrollClickWorker()
            self.scroll_worker.failed.connect(self.scroll_click_failed)
            self.scroll_worker.finished.connect(self.scroll_click_finished)
            self.scroll_worker.start()
        elif self.scroll_worker is not None:
            old_worker = self.scroll_worker
            self.scroll_worker.request_stop()
            self.scroll_worker.wait(500)
            self.scroll_worker = None
            self.retired_workers.append(old_worker)

    def scroll_click_failed(self, message: str) -> None:
        self.scroll_click_box.blockSignals(True)
        self.scroll_click_box.setChecked(False)
        self.scroll_click_box.blockSignals(False)
        self.config["shift_wheel_stash"] = False
        self.config.pop("ctrl_wheel_stash", None)
        core.save_config(self.config)
        QMessageBox.warning(self, "Scroll transfer disabled", message)

    def scroll_click_finished(self) -> None:
        finished_worker = self.sender()
        if self.scroll_worker is finished_worker:
            self.scroll_worker = None
        if isinstance(finished_worker, QThread) and finished_worker not in self.retired_workers:
            self.retired_workers.append(finished_worker)

    def start_xp_tracking(self) -> None:
        if self.xp_worker is not None and self.xp_worker.isRunning():
            return
        self.xp_worker = XpWorker(dict(self.config))
        self.xp_worker.updated.connect(self.update_xp_display)
        self.xp_worker.failed.connect(self.xp_tracking_failed)
        self.xp_worker.start()

    def update_xp_display(self, percent: str, rate: str, eta: str) -> None:
        self.xp_window.update_display(percent, rate, eta)

    def show_xp_window(self) -> None:
        self.xp_window.position_at_top_right()
        self.xp_window.show()
        self.xp_window.raise_()

    def xp_tracking_failed(self, message: str) -> None:
        self.update_xp_display("Unavailable", "—", "—")
        self.xp_window.percent_label.setToolTip(message)

    def closeEvent(self, event: QCloseEvent) -> None:
        self.xp_window.close()
        if self.xp_worker is not None:
            self.xp_worker.request_stop()
            self.xp_worker.wait(1000)
            self.xp_worker = None
        if self.scroll_worker is not None:
            self.scroll_worker.request_stop()
            self.scroll_worker.wait(500)
            self.scroll_worker = None
        if self.worker is not None and self.worker.isRunning():
            self.worker.request_stop()
            if not self.worker.wait(1500):
                event.ignore()
                return
        event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("PoE Life Monitor")
    app.setDesktopFileName("poe-life-monitor")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
