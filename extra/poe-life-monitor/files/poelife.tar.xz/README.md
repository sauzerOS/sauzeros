# Path of Exile X11 life monitor

This utility watches the life orb in the bottom-left Path of Exile HUD and
sounds an alert below a configurable level. It uses X11 screen
capture only: it does not read game memory, inject input, or modify the game.

It is calibrated for the current setup: Path of Exile at 2560x1440 on the X11
primary display, with maximum life 3,144.

## Desktop GUI

Open **PoE Life Monitor** from the application menu. Set the alert percentage
and current maximum life, then click **Start**. The GUI includes Stop, a live
orb-signal indicator, and a sound-test button. Settings are saved automatically
when monitoring starts.

The calculated numerical threshold is shown below the settings. Values remain
editable while monitoring; click **Apply** to save them and restart monitoring
at the new percentage.

The GUI also has an optional **Shift + mouse wheel transfers items** toggle for
X11. While Path of Exile is the active window, hold Shift, point at inventory
items, and turn the wheel; every wheel notch becomes one Ctrl+left-click. Normal
Shift+wheel behaviour is left unchanged in other applications. This is a
one-input-to-one-click remap and can be disabled immediately from the same
checkbox.

The separate translucent experience window reads the yellow fill boundary of
PoE's 20-section XP bar without accessing game memory. It shows the current
progress percentage, net XP percentage per hour over a rolling ten-minute
window, and the estimated time to the next level. Rate and ETA appear after 60
seconds of visible XP history; deaths are reflected as lost progress. On X11 it
uses an unmanaged always-above overlay so Wine cannot stack PoE over it. Drag
anywhere on the overlay to move it, right-click to hide it, and use the main
window's **XP window** button to show it again. Do not position the overlay over
PoE's actual XP bar, since the tracker must be able to capture that bar. XP
samples are recorded only while PoE is the focused X11 window, after eight
consistent frames confirm that the taskbar or a loading screen is no longer
covering the bar.

It can also be launched directly:

```bash
poe-life-monitor-gui
```

## Run it

```bash
poe-life-monitor 1500
```

The threshold can also be a percentage:

```bash
poe-life-monitor 40%
```

The default fast detector uses one persistent X11 capture stream for only a
130x11-pixel band of the orb corresponding to the configured life percentage.
It alerts on the first empty frame (normally about 0.05 seconds) and rearms
after that part of the orb fills again. Start it while life is above the
configured threshold so it can calibrate the globe's current artwork.

The same capture also watches the permanent gold rim at the top of the globe.
If that rim disappears during a loading screen or while the HUD is hidden,
alerts are paused. Monitoring resumes after ten visible HUD frames (about half
a second), allowing the globe to finish drawing before detection restarts.

Save a new default threshold:

```bash
poe-life-monitor 1500 --save
```

When the character or build changes maximum life, update both values in one
command. For example, for 4,200 maximum life with an alert at 2,000:

```bash
poe-life-monitor 2000 --max-life 4200 --save
```

You can use a percentage while changing maximum life; it is converted to a
life value and saved (this example saves an alert at 1,680):

```bash
poe-life-monitor 40% --max-life 4200 --save
```

Test the built-in sound or use your own sound file:

```bash
poe-life-monitor --test-sound
poe-life-monitor 1500 --sound /path/to/alert.ogg --save
```

Useful diagnostics:

```bash
poe-life-monitor --once
poe-life-monitor --show-crop /tmp/poe-life-crop.png
```

Exact-number OCR is retained as a fallback, but is slower and can be affected
by bright scenery behind the HUD:

```bash
poe-life-monitor 1500 --detection ocr
```

If the game is moved off the primary monitor, specify its X11 geometry and
optionally save it:

```bash
poe-life-monitor --screen 2560x1440+2560+0 --save
```

Settings can also be edited directly in
`~/.config/poe-life-monitor/config.json` (or under `$XDG_CONFIG_HOME`).

## Requirements

- X11 (including XWayland sessions where root capture is permitted)
- Python 3 with Pillow
- FFmpeg with `x11grab` support (used for the low-overhead persistent capture)
- Tesseract 5 only when using the optional `--detection ocr` fallback (the
  English recognition model is bundled locally)
- PipeWire `pw-play`, ALSA `aplay`, or `ffplay` for the alert
- X11's `libX11` and `libXtst` libraries for the optional scroll-transfer toggle
